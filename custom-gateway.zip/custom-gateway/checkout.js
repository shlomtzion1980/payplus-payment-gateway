const settings = window.wc.wcSettings.getSetting("my_custom_gateway_data", {});
const label =
  window.wp.htmlEntities.decodeEntities(settings.title) ||
  window.wp.i18n.__("My Custom Gateway", "my_custom_gateway");

const CustomInputField = ({ id, label }) => {
  return React.createElement(
    "div",
    { className: "custom-input-field" },
    React.createElement("label", { htmlFor: id }, label),
    React.createElement("input", {
      type: "checkbox",
      id: id,
      value: true,
      name: id,
      required: true,
    })
  );
};

// Define the content of your payment method including custom fields, without JSX
const Content = () => {
  return React.createElement(
    "div",
    null,
    React.createElement(
      "p",
      null,
      window.wp.htmlEntities.decodeEntities(settings.description || "")
    ),
    React.createElement(CustomInputField, {
      id: "wc-my_custom_gateway-new-payment-method",
      label: "Save My Card Details",
    })
    // Add additional fields as needed
  );
};

// const Content = () => {
//     return window.wp.htmlEntities.decodeEntities( settings.description || '' );
// };

const Block_Gateway = {
  name: "my_custom_gateway",
  label: label,
  content: Object(window.wp.element.createElement)(Content, null),
  edit: Object(window.wp.element.createElement)(Content, null),
  canMakePayment: () => true,
  ariaLabel: label,
  supports: {
    features: settings.supports,
  },
};
window.wc.wcBlocksRegistry.registerPaymentMethod(Block_Gateway);
